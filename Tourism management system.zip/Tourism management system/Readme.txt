How to run the Tourism Management System (TMS) Project

1. Download the zip file

2. Extract the file and copy tms folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4. Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with name tourism

6. Import tourism.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/tms (frontend)

Credential for admin panel :

Username: admin
Password: 1234

This project is free to use both personal and commercial

For commercial use, we recommend to first contact us to give support, improve on security and to add more useful functionalities

All our services are free don't fear to contact us on code4berryteam@gmail.com